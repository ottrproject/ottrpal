---
name: Add your new course to syncs/OTTR updates
about: Provide information about your new course (which uses the OTTR template) so that we can enroll it in OTTR updates
title: ''
labels: ''
assignees: cansavvy

---

## What is the name of your new repository?
<!-- The name of the repo. Ex the name of this repo is OTTR_Template -->

## What username or organization is your new repository associated with?
<!-- The name of the username or organization where the new repository is located . Ex this repository is part of the jhudsl organization. A personal repository would be associated with a username instead of the organization. -->
