---
title: Broken URLs found in the course!
labels: url-error
---
URL's in this course were just checked and some broken URLs were found.

**Number of errors:** {{ env.ERROR_NUM }}  
**File where errors are:** [url checks file here]({{ env.FILE_URL }})
