---
name: New content idea
about: Suggest an idea for the course
title: ''
labels: ''
assignees:

---

## Describe the your scope of your content idea
<!-- What will this cover and how does it relate to the current course material? -->

## Describe the learning objectives for your content idea
<!-- What will users learn from this new content? -->

## Additional context or resources
<!-- Add any other context or related resources we should know about? -->
